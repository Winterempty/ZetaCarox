# Start ZetaCaros

## Windows: easiest method

1. Install **Node.js 24 LTS** from the official Node.js website. Close and reopen terminal windows after installation.
2. Right-click the downloaded ZIP and select **Extract All**. Do not run files from inside the ZIP viewer.
3. Open the extracted `ZetaCaros-01-main` folder. It contains `package.json` and `START-WINDOWS.cmd`.
4. Double-click **START-WINDOWS.cmd**. Keep that window open.
5. When it says “ZetaCaros ready”, open **http://localhost:3000** in Chrome or Edge.
6. Copy the **First-run setup code** from the server window into the setup form. Enter your name, a username and a password with at least 12 characters.

There is no `npm install` step. The setup code changes if you restart before completing setup. Once the owner account exists, the code is no longer accepted.

### If using PowerShell

Open the extracted folder in File Explorer, click its address bar, type `powershell`, and press Enter. That opens PowerShell in the correct folder.

```powershell
node --version
Get-Item package.json
npm.cmd start
```

The Node version should begin with `v24`. If `package.json` cannot be found, you are in the wrong folder: return to the folder containing `START-WINDOWS.cmd`. Using `npm.cmd` avoids PowerShell's script-execution-policy issue without changing your system policy.

## Mac or Linux

Install Node.js 24.x, extract the ZIP, and open a terminal in the project folder:

```sh
npm start
```

Then open http://localhost:3000 and follow setup.

## First business setup

1. **Settings**: enter the business name and address, confirm THB or another supported currency, and select your business time zone. Set currency before adding products or financial records.
2. **Inventory → Add product**: enter a unique SKU, name, selling price, reference cost, opening stock and reorder point. Prices are per whole unit.
3. **Contacts → Add contact**: add a customer; add suppliers if you use purchase orders.
4. **Invoices → Create invoice**: select the customer and products, check quantity, issue/due dates, and the applicable tax rate. The default tax is zero; confirm what your business should use. Issuing deducts stock immediately.
5. Open an invoice and choose **Record payment** when you actually receive money. Partial payments are supported. Use **Print / Save PDF** for a printable copy.
6. **Purchase orders**: create an order, then open it and receive it once the full delivery arrives. Receiving increases stock but does not mark the supplier as paid.
7. **Expenses**: record payments to suppliers and other cash expenses. Include the purchase-order number in the note if relevant.
8. **Settings → Add team member**: create separate accounts. Staff operate the business; viewers can read/export all business data; admins control users, backups, settings, product edits and voids.
9. **Reports → Download backup**: save a database backup after each business day and keep a protected copy on another device.

## Daily use

Start the server, sign in, review low stock and overdue invoices, enter sales and receipts, receive stock and record expenses. Refresh the screen when another team member has made changes. Back up at day end. Stop the server with **Ctrl+C**, then close its window.

Records live in `data/business.sqlite`, not in your browser. Keep the entire `data` folder when moving or updating the app. Clearing browser data signs you out but does not delete business records. Deleting the project folder can delete your database.

## Troubleshooting

- **Node is not recognized**: install Node.js 24 LTS and open a new terminal.
- **Page cannot be reached**: keep the server window open and check it for an error; verify port 3000 is not used by another app.
- **Database is in use**: another instance may be running. Stop it before restarting. After an abnormal crash, confirm that no ZetaCaros Node process remains, then delete only `data/business.sqlite.lock` and retry. Never delete database or WAL files to fix a lock.
- **Sign-in expired**: sign in again; sessions last eight hours.
- **Forgot staff password**: an admin can reset it in Settings. Keep a second trusted admin account for owner account recovery; this release has no email recovery service.
- **Wrong invoice**: admins can void an unpaid invoice and reissue it; products are returned to stock. Paid-invoice corrections/refunds are outside this release.
- **More than one computer**: localhost is intentionally limited to the host computer. Have an administrator configure the HTTPS deployment in `docs/OPERATIONS.md` before staff connect from other devices.
