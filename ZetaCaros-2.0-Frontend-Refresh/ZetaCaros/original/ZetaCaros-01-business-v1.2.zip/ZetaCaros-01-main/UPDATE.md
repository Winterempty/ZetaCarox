# Update from 1.0 or 1.1 to 1.2 without losing data

This is a source-code update. Database schema remains version 1. Existing users, passwords, inventory, invoices and other records remain in your current `data` folder.

1. In the current application, download a backup from Reports or Settings.
2. Stop the current server: press **Ctrl+C** in its black terminal window.
3. Extract the new ZIP into a **separate folder** first.
4. Open its `ZetaCaros-01-main` folder. Copy its contents **into your existing application folder**—the folder that already contains `START-WINDOWS.cmd` and `data`.
5. Choose **Replace files** when Windows asks. **Keep your existing `data` folder. Do not delete your old project folder.** The update ZIP does not contain a `data` folder or test accounts.
6. Start `START-WINDOWS.cmd` from that existing folder. Open http://localhost:3000, then press **Ctrl+F5** to load the updated screen.
7. Sign in using your existing username and password. Choose **ไทย** in the **Language** menu at the top. Choose **Larger / ใหญ่** if desired.

If you see the first-time setup form instead of sign-in, stop: you probably started the newly extracted copy rather than your existing installation. Close it and start from your original application folder. If you use a custom `DB_PATH`, keep the same setting.

Do not create another account to solve missing data. The previous data has not moved automatically between folders.

## อัปเดตโดยเก็บข้อมูลเดิม

1. ดาวน์โหลดข้อมูลสำรองจากเมนู Reports / รายงาน หรือ Settings / ตั้งค่า
2. กด **Ctrl+C** ในหน้าต่างสีดำเพื่อหยุดโปรแกรมเดิม
3. แตกไฟล์ ZIP ใหม่ไว้ในโฟลเดอร์แยกก่อน
4. เปิดโฟลเดอร์ `ZetaCaros-01-main` จากไฟล์ใหม่ แล้วคัดลอกไฟล์และโฟลเดอร์ข้างในไปวางใน **โฟลเดอร์โปรแกรมเดิม** ที่มี `START-WINDOWS.cmd` และ `data`
5. เลือกแทนที่ไฟล์เมื่อระบบถาม **เก็บโฟลเดอร์ `data` เดิมไว้ ห้ามลบโฟลเดอร์โปรแกรมเดิม**
6. เปิด `START-WINDOWS.cmd` จากโฟลเดอร์เดิม เข้า http://localhost:3000 แล้วกด **Ctrl+F5**
7. เข้าสู่ระบบด้วยบัญชีเดิม เลือก **ไทย** ที่เมนู **Language** ด้านบน และเลือกขนาดตัวอักษร **ใหญ่** ได้ตามต้องการ

หากเห็นหน้าสร้างบัญชีใหม่ ทั้งที่เคยใช้งานแล้ว ให้หยุดโปรแกรมและตรวจสอบว่าเปิดจากโฟลเดอร์เดิม อย่าเพิ่งสร้างบัญชีใหม่เพื่อแก้ปัญหาข้อมูลหาย

After updating, open **Business health / ดูแนวโน้มธุรกิจ** from the sidebar or Overview. No new account, database migration, external service or AI key is required.
