@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24 LTS, then run this file again.
  pause
  exit /b 1
)
node -e "if (Number(process.versions.node.split('.')[0]) !== 24) { console.error('Please use Node.js 24 LTS.'); process.exit(1); }"
if errorlevel 1 (
  pause
  exit /b 1
)
echo Open http://localhost:3000 in your browser after the ready message.
echo Keep this window open. Press Ctrl+C to stop the server.
node backend/src/app.js
pause
