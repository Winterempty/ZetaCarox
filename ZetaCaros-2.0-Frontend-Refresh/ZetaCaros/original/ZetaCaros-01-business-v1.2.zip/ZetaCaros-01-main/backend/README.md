# Backend

The former placeholder is now a Node.js 24 HTTP application backed by SQLite. Run commands from the project root:

```sh
npm start
npm test
```

No runtime dependencies need installation. See the root README and `docs/OPERATIONS.md` for setup, business rules, deployment and recovery.

The original empty controller/model/service directories are retained as scaffolding. The implemented server is in `src/app.js`, schema in `src/database.js`, and offline maintenance in `src/maintenance.js`.
