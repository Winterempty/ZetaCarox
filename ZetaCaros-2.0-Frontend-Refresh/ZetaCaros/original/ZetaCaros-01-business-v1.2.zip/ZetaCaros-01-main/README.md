# ZetaCaros Business Workspace · 1.2

A working, single-business operations application developed from the BizAnalytics visual prototype. Manage inventory, customer invoices and receipts, suppliers and purchasing, expenses, team access, exports and database backups.

**Start here:** [QUICKSTART.md](QUICKSTART.md) · [คู่มือภาษาไทย](QUICKSTART-TH.md).

**Updating from v1.0 or v1.1?** Read [UPDATE.md](UPDATE.md) to keep your existing accounts and data. Windows users can double-click `START-WINDOWS.cmd` after installing Node.js 24 LTS. There are no runtime npm dependencies or CDN requirements.

```sh
npm start
```

Open http://localhost:3000. Copy the one-time setup code from the terminal and create your owner account. The application starts with **no sample business records and no default credentials**.

## New in 1.2: Business health

Open **Business health / ดูแนวโน้มธุรกิจ** for six completed months of sales, receipts, expenses and recorded cash differences. It compares the last two completed months, shows this month separately, and links plain-language action suggestions to the relevant records. English remains the initial default. See [docs/BUSINESS-HEALTH.md](docs/BUSINESS-HEALTH.md).

## What works

- Responsive dashboard with recorded cash totals, low-stock alerts, overdue invoices and recent activity.
- Products with unique SKUs, prices, reference costs, opening stock, reorder levels, adjustments with reasons, and archiving.
- Customers and suppliers with contact details; Unicode/Thai names supported.
- Multi-line invoices using server-controlled prices, integer money calculations, invoice-level tax, stock deduction, partial/full payment recording, invoice printing/PDF through the browser, and unpaid-invoice void/restock.
- Purchase orders with full delivery receiving and cancellation.
- Expenses with categories, references and admin voiding.
- Owner/admin, staff and viewer accounts; session expiry; password changes; staff password resets; account disablement.
- Readable Thai/English CSV exports with amounts in business currency, editable contacts, recent activity and stock histories, database backup download and offline restore.
- SQLite transactions, duplicate-request protection, validation, role enforcement, same-origin/CSRF controls, security headers, scrypt password hashing, and restart persistence.
- THB and Bangkok time by default; business details and time zone configurable. Currency locks when the first product/financial record exists.

## Operating model and release boundary

This is an operational **v1 for a controlled pilot**, not a certified accounting system or a claim of audited, enterprise-grade readiness. Run one process, one business and one local SQLite database on a dedicated host. All staff/viewers can see business financial records; roles restrict actions, not department-level visibility.

Use it for modest-volume, whole-unit stock and invoice workflows. It has not been load-tested for a medium-sized organization. List screens paginate in the browser while the API currently loads the full workspace; larger datasets need server-side pagination and capacity testing before rollout.

The interface supports English and Thai. English is the initial default; use Language / ภาษา in the sign-in page or header to switch. Text size can be increased, and both preferences are remembered per browser. Existing prototype HTML is preserved as design reference, not served as the live application. AI forecasting, statutory tax filing, automated bank reconciliation, refunds/credit notes, partial purchase receiving, multi-warehouse stock, fractional quantities, multi-company operation, offline browser sync and automatic email sending are not implemented. See [docs/OPERATIONS.md](docs/OPERATIONS.md) before putting live records into service.

## Commands

| Command | Purpose |
| --- | --- |
| `npm start` | Run the business application |
| `npm test` | Run backend integration and money-validation tests against temporary databases |
| `npm run backup` | Offline consistent backup; stop the server first |
| `npm run restore -- path/to/backup.sqlite --confirm` | Offline restore; retains the previous database and clears sessions |

No `npm install` is needed to run the app or the standard tests. The optional `test:ui` script uses the development-only `jsdom` package. Use Node.js **24.x**. This release uses the built-in `node:sqlite` API; upgrade Node major versions only after testing.

## Project layout

- `public/`: live web interface; local assets only.
- `backend/src/app.js`: HTTP server, authentication, authorization and business endpoints.
- `backend/src/database.js`: versioned SQLite schema.
- `backend/src/maintenance.js`: backup validation and restore operations.
- `backend/src/lock.js`: single-process database ownership lock.
- `backend/tests/business.test.js`: integration tests.
- `docs/`: operations, API reference and release verification.
- `AI-BAT/c24.html`, `Protoype/SAS.html`: original prototype references.
- `data/`: created on first start; excluded from version control. Keep it private.

## Collaboration

The repository owner remains [`@TeeraWowzers`](https://github.com/TeeraWowzers). Create a branch and open a pull request for these changes; do not push directly to `main` or merge without owner approval. Existing `.github/CODEOWNERS` and the pull request template are preserved.

This ZIP was developed from the supplied archive. It has not been pushed, merged or deployed to GitHub.
